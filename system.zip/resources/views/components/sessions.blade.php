<div {{ $attributes->merge(['class' => 'shadow-md rounded-2xl bg-white dark:bg-gray-800 p-4 m-5']) }}>
    {{ $content }}
</div>
